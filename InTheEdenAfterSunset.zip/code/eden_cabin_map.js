simpleFrameworks.addto('iModFooter', {
    passage: ['Eden Clearing','Clearing Weeding','Clearing Eden Actions','Eden Porch','Clearing Spring','Eden Plots','Clearing Fondle','Eden Lunch',"Eden Shoot","Eden Shoot First Focus"],
    widget: 'Eden_Cabin_Map',
});
simpleFrameworks.addto('iModHeader', {
    passage: ['Eden Clearing','Clearing Weeding','Clearing Eden Actions','Eden Porch','Clearing Spring','Eden Plots','Clearing Fondle','Eden Lunch',"Eden Shoot","Eden Shoot First Focus"],
    widget: 'Eden_Map_Actions',
});
simpleFrameworks.addto('iModFooter', {
    passage: ['Eden Cabin','Eden Bath 2','Eden Bath','Eden Bath Wash No','Eden Bath Wash','Eden Breakfast','Eden Breakfast 2','Eden Dinner','Eden Christmas Meal 2','Eden Read','Eden Read Tease','Eden Table','Eden Cabin Bed','Cabin Sleep','Eden Mirror','Eden Caged Intro','Eden Caged','Eden Caged Caught','Eden Caged Evening','Eden Sleep Push','Cabin Eden Actions','Eden Cuddle','Eden Cuddle Talk','Eden Cuddle Trauma Talk','Eden Caged Breakfast','Eden Caged Escape','Eden Caged Freedom','Eden Dance','Eden Wounds','Eden Wounds Insist','Eden Wounds Finish','Eden Cuddle Trauma Honest','Eden Cuddle Trauma Honest 2','Eden Cuddle Trauma Honest 3'],
    widget: 'Eden_Indoor_Map',
});
simpleFrameworks.addto('iModHeader', {
    passage: ['Eden Cabin','Eden Bath 2','Eden Bath','Eden Bath Wash No','Eden Bath Wash','Eden Breakfast','Eden Breakfast 2','Eden Dinner','Eden Christmas Meal 2','Eden Read','Eden Read Tease','Eden Table','Eden Cabin Bed','Cabin Sleep','Eden Mirror','Eden Caged Intro','Eden Caged','Eden Caged Caught','Eden Caged Evening','Eden Sleep Push','Cabin Eden Actions','Eden Cuddle','Eden Cuddle Talk','Eden Cuddle Trauma Talk','Eden Caged Breakfast','Eden Caged Escape','Eden Caged Freedom','Eden Dance','Eden Wounds','Eden Wounds Insist','Eden Wounds Finish','Eden Cuddle Trauma Honest','Eden Cuddle Trauma Honest 2','Eden Cuddle Trauma Honest 3'],
    widget: 'Eden_Indoor_Map_Actions',
});

